# 11-667 Homework 3

Starter code for HW 3 for Fall 2023.

Note that this does _not_ include code to train or decode from your model; you may use either your Homework 2 code or a Hugging Face/PyTorch implementation of your choice. 
