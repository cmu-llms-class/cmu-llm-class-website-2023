

def clean_pii(text):
    """Returns text with email addresses, social security numbers, and phone numbers removed."""
    raise NotImplementedError()

def filter_noneng(text):
    """Returns True if the text is contains non-English characters."""
    raise NotImplementedError()

def clean_other(text):
    """Add your own custom cleaning and/or filtering operations here."""
    raise NotImplementedError()
