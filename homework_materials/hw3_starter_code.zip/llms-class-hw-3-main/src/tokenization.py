import tiktoken 

tokenizer = tiktoken.get_encoding('gpt2')


def return_duplicate_tokens():
    token_list_one = []
    token_list_two = []
    raise NotImplementedError()

    return token_list_one, token_list_two


